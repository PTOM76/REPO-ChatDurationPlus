# ChatDurationPlus (R.E.P.O Mod)
チャットの表示時間を15秒延長します。<br />
`ChatDurationPlus.json` にて延長時間を変更できます。

Extends chat message display time by 15 seconds.<br />
The display duration can be adjusted in `ChatDurationPlus.json`.