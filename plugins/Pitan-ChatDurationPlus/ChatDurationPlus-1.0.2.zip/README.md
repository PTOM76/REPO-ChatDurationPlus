# ChatDurationPlus (R.E.P.O Mod)
- Nexusmods: https://www.nexusmods.com/repo/mods/150
- Thunderstore: https://thunderstore.io/c/repo/p/PTOM76/ChatDurationPlus/

Extends chat message display time by 15 seconds.<br />
The display duration can be adjusted in `ChatDurationPlus.json`.

チャットの表示時間を15秒延長します。<br />
`ChatDurationPlus.json` にて延長時間を変更できます。

## Install
Save as `(GameDirectory)\BepInEx\plugins\ChatDurationPlus\ChatDurationPlus.dll`
